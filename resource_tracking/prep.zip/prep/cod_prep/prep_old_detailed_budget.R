
# ----------------------------------------------
# Irena Chen
#
# 12/18/2017
# Template for prepping GF detailed budget data  
# Inputs:
# inFile - name of the file to be prepped
# Outputs:
# budget_dataset - prepped data.table object
# ----------------------------------------------

prep_old_detailed_budget = function(dir, inFile, sheet_name, start_date, 
                                qtr_num, disease, period, lang, grant, loc_id, source, recipient){
 
  ##read the data: 
  gf_data <- data.table(read_excel(paste0(dir, inFile), sheet=as.character(sheet_name)))
  
  gf_data <- gf_data[,-c(1:2)]
  if(sheet_name=="Budget d�taill� - Ann�e 3."){
    qtr_names <- c("X__6" ,"X__7")
  } else {
    qtr_names <- c("X__4", "X__5", "X__6" ,"X__7")
  }
  col_names <- c("Domaine de prestation de services (DPS)","Activit�","Cat�gorie de co�t" ,qtr_names)
  
  ##only keep data that has a value in the "category" column 
  gf_data <- gf_data[,names(gf_data)%in%col_names, with=FALSE]
  
  gf_data <- na.omit(gf_data, cols=1, invert=FALSE)
  colnames(gf_data)[1] <- "module"
  colnames(gf_data)[2] <- "sda_activity"
  colnames(gf_data)[3] <- "cost_category"

  
  ## invert the dataset so that budget expenses and quarters are grouped by category
  ##library(reshape)
  setDT(gf_data)
  gf_data1<- melt(gf_data,id=c("module","sda_activity","cost_category"), variable.name = "qtr", value.name="budget")

  
  dates <- rep(start_date, qtr_num) # 
  for (i in 1:length(dates)){
    if (i==1){
      dates[i] <- start_date
    } else {
      dates[i] <- dates[i-1]%m+% months(3)
    }
  }
  
  if(length(dates) != length(unique(gf_data1$qtr))){
    stop('quarters were dropped!')
  }
  
  ##turn the list of dates into a dictionary (but only for quarters!) : 
  dates <- setNames(dates,unique(gf_data1$qtr))
  
  
  ## now match quarters with start dates 
  kDT = data.table(qtr = names(dates), value = TRUE, start_date = unname(dates))
  budget_dataset <-gf_data1[kDT, on=.(qtr), start_date := i.start_date ]
  budget_dataset <- na.omit(budget_dataset, cols=1, invert=FALSE)
  budget_dataset$qtr <- NULL
  budget_dataset$period <- period
  budget_dataset$intervention <- "all"
  budget_dataset$loc_name <- loc_id
  budget_dataset$recipient <- recipient
  budget_dataset$disease <- disease
  budget_dataset$expenditure <- 0 
  budget_dataset$grant_number <- grant
  budget_dataset$lang <- lang
  budget_dataset$data_source <- source
  return(budget_dataset)
  
}


